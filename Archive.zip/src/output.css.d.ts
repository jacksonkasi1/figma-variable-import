declare const styles: {
  readonly "border": string;
  readonly "flex": string;
  readonly "flex-col": string;
  readonly "font-bold": string;
  readonly "gap-4": string;
  readonly "grid": string;
  readonly "items-center": string;
  readonly "justify-center": string;
  readonly "mb-4": string;
  readonly "text-center": string;
  readonly "text-gray-500": string;
  readonly "text-green-600": string;
  readonly "text-red-500": string;
  readonly "text-sm": string;
  readonly "text-xl": string;
  readonly "text-xs": string;
};
export = styles;

